<?php
//Connect to MySQL Database
$hostname = "uta.cloud";
$username = "vvs1620_vivekshetye";
$password = "Shaleshwar12@";
$database = "vvs1620_database";

$con = mysqli_connect($hostname, $username, $password, $database);
?>